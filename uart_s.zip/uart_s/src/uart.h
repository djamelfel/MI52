#define INT_METHOD
//#define POLLING_METHOD

/* define the priority grouping for the cortex-M implemented in STM32 */
#define NVIC_PRIORITYGROUP_4	((uint32_t)0x00000003)

void set_USART2(void);
uint32_t UART_Transmit(USART_TypeDef * uart, uint8_t * data, uint32_t len);
uint32_t UART_Receive(USART_TypeDef * uart, uint8_t * data, uint32_t len, uint32_t time_out);
uint32_t UART_Transmit_IT(USART_TypeDef * uart, uint8_t * data, uint32_t len);
uint32_t UART_Receive_IT(USART_TypeDef * uart, uint8_t * data, uint32_t len);
void USART2_IRQHandler(void);
void UART_TX_complete_callback();
void UART_RX_complete_callback();
uint32_t UART_Transmit_DMA(USART_TypeDef * uart, uint8_t * data, uint32_t len);
uint32_t UART_Receive_DMA(USART_TypeDef * uart, uint8_t * data, uint32_t len);
void DMA1_Stream5_IRQHandler(void);
void DMA1_Stream6_IRQHandler(void);

#ifdef INT_METHOD

typedef struct{
	USART_TypeDef  * instance; /* address of the USART registers */
	uint32_t state; 	   /* can be used as a lock for transmission and reception, error, ... */
	uint8_t * pTxBuffer;	   /* application buffer for transmission */
	uint8_t * pRxBuffer; 	   /* application buffer for reception */
	uint32_t TxSize;	   /* number of data to transmit */
	uint32_t RxSize;	   /* number of data to receive */
	uint32_t TxCount; 	   /* number of data already transmitted */
	uint32_t RxCount; 	   /* number of data already received */
} UART_Device;

UART_Device uartDev;

#endif

