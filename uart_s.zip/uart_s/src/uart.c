#include <stm32f4xx.h>
#include "uart.h"

void set_USART2(void)
{   	 
	/* define port instance */
	RCC_TypeDef * rcc = RCC;
	GPIO_TypeDef * gpioa = GPIOA;
	USART_TypeDef * usart = USART2;
	//DMA_TypeDef * dma = DMA1;
	//DMA_Stream_TypeDef * dmas5 = DMA1_Stream5;
	//DMA_Stream_TypeDef * dmas6 = DMA1_Stream6;

	/*-------------- clock enable --------------- */
	/* Enable GPIOA clock */
	rcc->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
	/* Enable USARTx clock */
	rcc->APB1ENR |= RCC_APB1ENR_USART2EN;
	/* enable DMA1 clock */
	rcc->APB1ENR |= (1<<20) ;// RCC_APB1ENR_DMA1EN;


	/*-------------- Pin muxing configuration --------------- */
	/* Configure alternate function for UART2 RX and TX */
	gpioa->MODER |= GPIO_MODER_MODER2_1
			| GPIO_MODER_MODER3_1;
	/* set up alternate function 7 for PA2 (TX)  */
	gpioa->AFR[0] |= (0b0111<<8);
	/* set up alternate function 7 for PA3 (RX) */
	gpioa->AFR[0] |= (0b0111<<12);

	/*-------------- UART parameters configuration --------------- */
	/* Configure USART CR1 */
	usart->CR1 |= 0b1010000000001100;
	/* Configure USART CR2 */
	usart->CR2 |= 0b0000000000000000;
	/* Configure USART CR3 */
	usart->CR3 |= 0b0000000000000000;
	/* USART BRR Configuration */
	usart->BRR = 0x2D5;

    /* enable USART (CR1) */ // Done in conf CR1
	usart->CR1 &= ~USART_CR1_TXEIE;
	usart->CR1 &= ~USART_CR1_RXNEIE;

	/*-------------- DMA1 parameters configuration fur USART2 --------------- */
	/* set up the DMA chanel 4 stream 5 for USART2 RX */
// 	dmas5->
	/* set up the DMA chanel 4 stream 6 for USART2 TX */

	/*-------------- interrupt --------------- */
	/* set up priority and autorize interrupt example : */
	
#ifdef INT_METHOD
    // Initialize struct
    uartDev.state = 0;
    uartDev.TxCount = 0;
    uartDev.RxCount = 0;

/*	usart->CR1 |= USART_CR1_TXEIE;
	usart->CR1 |= USART_CR1_RXNEIE;*/

	NVIC_SetPriorityGrouping( NVIC_PRIORITYGROUP_4 );
	NVIC_SetPriority(USART2_IRQn,0x2);

	NVIC_EnableIRQ(USART2_IRQn);

//	__enable_irq();

#endif
/*	NVIC_SetPriority(DMA1_Stream5_IRQn,0x30);
	NVIC_EnableIRQ(DMA1_Stream5_IRQn);
	NVIC_SetPriority(DMA1_Stream6_IRQn,0x30);
	NVIC_EnableIRQ(DMA1_Stream6_IRQn);
*/
}

/* user functions using polling method */
uint32_t UART_Transmit(USART_TypeDef * uart, uint8_t * data, uint32_t len)
{
	int i = 0;
	while(i < len){
		while(!(uart->SR & USART_SR_TXE)) ;
		uart->DR = data[i];
		i++;	
	}	
}

uint32_t UART_Receive(USART_TypeDef * uart, uint8_t * data, uint32_t len, uint32_t time_out)
{
	int t = time_out;
	int i = 0;

	while(i < len){
		t = time_out;
		while(!(uart->SR & USART_SR_RXNE)){
			t--;
			if(t == 0)
				return 0;
		}
		data[i++] = uart->DR;
	}
}

/* user functions using interrupt driven method */
uint32_t UART_Transmit_IT(USART_TypeDef * uart, uint8_t * data, uint32_t len)
{
	uartDev.instance = uart;
    uartDev.pTxBuffer = data;
    uartDev.TxSize = len;
    uartDev.TxCount = 1;
    uart->DR = data[0];

	uartDev.instance->SR &= ~USART_SR_TC;

	uartDev.instance->CR1 |= USART_CR1_TXEIE;
	uartDev.instance->CR1 |= USART_CR1_TCIE;
}

uint32_t UART_Receive_IT(USART_TypeDef * uart, uint8_t * data, uint32_t len)
{
    uartDev.instance = uart;
    uartDev.pRxBuffer = data;
    uartDev.RxSize = len;
    uartDev.RxCount = 0;

	uartDev.instance->CR1 |= USART_CR1_RXNEIE;
}

/* USART2 ISR */
void USART2_IRQHandler(void)
{
    if(uartDev.instance->SR & USART_SR_TXE){ // if tx finished
        if(uartDev.TxCount < uartDev.TxSize){
            uartDev.TxSize--;
            uartDev.TxCount++;
            uartDev.instance->DR = uartDev.pTxBuffer[uartDev.TxCount];
        }else // call callback
            UART_TX_complete_callback();
    }

    if(uartDev.instance->SR & USART_SR_RXNE){ // rx received
        if(uartDev.RxSize > 0){
            uartDev.RxSize--;
            uartDev.pRxBuffer[uartDev.RxCount] = uartDev.instance->DR;
            uartDev.RxCount++;
            uartDev.instance->SR &= !USART_SR_RXNE;
        }else
            UART_RX_complete_callback();
    }
}

void UART_TX_complete_callback(){
	uartDev.instance->CR1 &= ~USART_CR1_TXEIE;
	uartDev.instance->CR1 &= ~USART_CR1_TCIE;
	uartDev.instance->SR |= USART_SR_TC;
	UART_Receive_IT(uartDev.instance, uartDev.pRxBuffer, 1);
}
void UART_RX_complete_callback(){
	uartDev.instance->CR1 &= ~USART_CR1_RXNEIE;
	UART_Transmit_IT(uartDev.instance,uartDev.pRxBuffer,1);
}


/* user functions using DMA and interrupt method */
uint32_t UART_Transmit_DMA(USART_TypeDef * uart, uint8_t * data, uint32_t len)
{
}
uint32_t UART_Receive_DMA(USART_TypeDef * uart, uint8_t * data, uint32_t len)
{
}

/* DMA1 Stream 5 ISR */
void DMA1_Stream5_IRQHandler(void)
{
}

/* DMA1 Stream 6 ISR */
void DMA1_Stream6_IRQHandler(void)
{
}
	

