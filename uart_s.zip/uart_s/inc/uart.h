#ifndef UART_H
#define UART_H


/* Definition for USARTx Pins */
#define USART2_TX_PIN                    2
#define USART2_TX_AF                     7
#define USART2_RX_PIN                    3
#define USART2_RX_AF                     7

/* function definition */
void set_USART2(void);
uint32_t UART_Transmit(USART_TypeDef * uart, uint8_t * data, uint32_t len);
uint32_t UART_Receive(USART_TypeDef * uart, uint8_t * data, uint32_t len, uint32_t time_out);
uint32_t UART_Transmit_IT(USART_TypeDef * uart, uint8_t * data, uint32_t len);
uint32_t UART_Receive_IT(USART_TypeDef * uart, uint8_t * data, uint32_t len);
void USART2_IRQHandler(void);
uint32_t UART_Transmit_DMA(USART_TypeDef * uart, uint8_t * data, uint32_t len);
uint32_t UART_Receive_DMA(USART_TypeDef * uart, uint8_t * data, uint32_t len);
void DMA1_Stream5_IRQHandler(void);
void DMA1_Stream6_IRQHandler(void);

#endif /*UART_H*/
